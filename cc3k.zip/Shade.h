#ifndef __SHADE_H__
#define __SHADE_H__

#include "Race.h"
#include "CellType.cc"

class Shade: public Race {
public:
  Shade();
};

#endif
