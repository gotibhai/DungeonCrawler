#ifndef __DWARF_H__
#define __DWARF_H__
#include "Enemy.h"

class Dwarf: public Enemy {
public:
  Dwarf();
};

#endif
