#include "Dwarf.h"

Dwarf::Dwarf(): Character{100,20,30}, Cell{CellType::Dwarf} {}

