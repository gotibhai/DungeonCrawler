#ifndef __HALFLING_H__
#define __HALFLING_H__
#include "Enemy.h"
class Halfling: public Enemy {
public:
    Halfling();
};

#endif
