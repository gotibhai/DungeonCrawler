#include "Troll.h"

Troll::Troll(): Race{120, 25, 15}, Cell{CellType::Troll} {

}

// bool Troll::move(Direction direction) {

// };
