#include "Halfling.h"

Halfling::Halfling(): Character{100, 15, 20}, Cell{CellType::Halfling} {}
