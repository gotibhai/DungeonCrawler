#include "Shade.h"

Shade::Shade(): Race{50, 25, 25}, Cell{CellType::Shade} {}
