#include "Drow.h"
#include "Cell.h"

Drow::Drow(): Race{150, 25, 15}, Cell{CellType::Drow} {

}

void Drow::use(class Potion potion) {
  
}
