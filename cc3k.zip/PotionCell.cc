#include "PotionCell.h"
#include "Game.h"


class Potion PotionCell::getPotion(){
	return potion;
}
