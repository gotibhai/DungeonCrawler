#ifndef __GOLDTYPE_H__
#define __GOLDTYPE_H__

enum GoldType{
	NormalGold = 2,
	SmallGold = 1,
	MerchantGold = 4,
	DragonGold = 6
};

#endif
