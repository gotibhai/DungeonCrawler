#ifndef __TROLL_H__
#define __TROLL_H__

#include "Race.h"
#include "CellType.cc"
#include "Direction.cc"


class Troll: public Race {
public:
  Troll();
  // bool move(Direction) override;
};

#endif
