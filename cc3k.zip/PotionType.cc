#ifndef __POTIONTYPE_H__
#define __POTIONTYPE_H__


enum PotionType {
	RH,
	BA,
	BD,
	PH,
	WA,
	WD
};

#endif
