#include "Goblin.h"

Goblin::Goblin(): Race{110, 15, 20}, Cell{CellType::Goblin} {

}

void Goblin::winBattle() {

}
